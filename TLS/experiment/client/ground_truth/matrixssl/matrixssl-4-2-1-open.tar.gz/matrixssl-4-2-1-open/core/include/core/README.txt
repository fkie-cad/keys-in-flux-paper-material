This directory is to support #include "core/*.h" 
