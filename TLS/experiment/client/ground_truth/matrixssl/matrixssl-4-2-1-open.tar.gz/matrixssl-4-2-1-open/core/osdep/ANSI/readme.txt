The files in this directory use ANSI-C also known as ISO C90 interfaces.
These interfaces are the lowest common denominator for all standard C interfaces.
Therefore, the files below are very likely to work for almost all targets.

Note: Some of embedded targets do not include all of these APIs, in the name of
footprint reduction.
